#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QApplication>
#include <QTranslator>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->btnShowMessage, &QPushButton::clicked, this, &MainWindow::on_btnShowMessage_clicked);
    connect(ui->comboLanguage, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &MainWindow::on_comboLanguage_currentIndexChanged);

    ui->comboLanguage->setCurrentIndex(0);
    on_comboLanguage_currentIndexChanged(ui->comboLanguage->currentIndex());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btnShowMessage_clicked()
{
    QString firstName = ui->lineName->text();
    QString lastName = ui->lineLastName->text();
    QString gender = ui->comboGender->currentText();
    QString level = ui->comboLevel->currentText();

    QString language = ui->comboLanguage->currentText();
    QString message;
    if (language == "Español") {
        message = QString("Nombre: %1\nApellido: %2\nGénero: %3\nNivel: %4")
                      .arg(firstName)
                      .arg(lastName)
                      .arg(gender)
                      .arg(level);
    } else {
        message = QString("First Name: %1\nLast Name: %2\nGender: %3\nLevel: %4")
                      .arg(firstName)
                      .arg(lastName)
                      .arg(gender)
                      .arg(level);
    }

    QMessageBox::information(this, tr("Datos Ingresados"), message);
}

void MainWindow::on_comboLanguage_currentIndexChanged(int index)
{
}
