<context>
    <name>MainWindow</name>
    <message>
        <source>Elegir Idioma:</source>
        <translation>Choose Language:</translation>
    </message>
    <message>
        <source>Nombre:</source>
        <translation>First Name:</translation>
    </message>
    <message>
        <source>Apellido:</source>
        <translation>Last Name:</translation>
    </message>
    <message>
        <source>Género:</source>
        <translation>Gender:</translation>
    </message>
    <message>
        <source>Nivel:</source>
        <translation>Level:</translation>
    </message>
    <message>
        <source>Mostrar mensaje</source>
        <translation>Show Message</translation>
    </message>
    <message>
        <source>Datos Ingresados</source>
        <translation>Entered Data</translation>
    </message>
</context>
