<context>
    <name>MainWindow</name>
    <message>
        <source>Elegir Idioma:</source>
        <translation>Elegir Idioma:</translation>
    </message>
    <message>
        <source>Nombre:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <source>Apellido:</source>
        <translation>Apellido:</translation>
    </message>
    <message>
        <source>Género:</source>
        <translation>Género:</translation>
    </message>
    <message>
        <source>Nivel:</source>
        <translation>Nivel:</translation>
    </message>
    <message>
        <source>Mostrar mensaje</source>
        <translation>Mostrar mensaje</translation>
    </message>
    <message>
        <source>Datos Ingresados</source>
        <translation>Datos Ingresados</translation>
    </message>
</context>
