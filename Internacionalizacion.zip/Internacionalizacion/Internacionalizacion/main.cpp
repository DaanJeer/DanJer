#include <QApplication>
#include <QTranslator>
#include <QLocale>
#include <QLibraryInfo>
#include "mainwindow.h"
#include <QDebug>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QTranslator translator;
    QString locale = QLocale::system().name();
    qDebug() << "System locale:" << locale;

    bool loaded = false;
    if (locale.startsWith("es")) {
        loaded = translator.load(":/translation_es.qm");
        qDebug() << "Loading Spanish translation file: :/translation_es.qm";
    } else {
        loaded = translator.load(":/translation_en.qm");
        qDebug() << "Loading English translation file: :/translation_en.qm";
    }

    if (loaded) {
        app.installTranslator(&translator);
        qDebug() << "Translation file loaded successfully.";
    } else {
        qWarning() << "Error loading translation file.";
    }

    MainWindow w;
    w.show();
    return app.exec();
}
